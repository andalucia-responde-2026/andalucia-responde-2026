# ANDALUCÍA RESPONDE – REPORTE CONSOLIDADO

Sitio web estático listo para publicar en GitHub Pages.

Fuente de datos:
`REPORTE CONSOLIDADO ANDALUCIA J.xlsx`

El contenido fue estructurado por:
- Población y vivienda
- Salud
- Educación
- Edificaciones públicas
- Vías
- Locales comerciales
- Servicios esenciales
- PMU
- Albergues
- Atención humanitaria
- Maquinaria y personal profesional
- Materiales de construcción
- Requerimientos prioritarios

Importante:
- `0` significa que el reporte registra cero.
- `— / No reportado` significa que el Excel no aporta una cifra.
- La página evita convertir datos faltantes en ceros.

Para publicar: subir `index.html`, `styles.css`, `data.json` a un repositorio y activar GitHub Pages.
